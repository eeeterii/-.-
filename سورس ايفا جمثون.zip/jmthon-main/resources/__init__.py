from .blacklist import blacklisted_users
LIST = {}
DEVLIST = [1280124974, 1234567890]
