from telethon.tl import functions as fun

delattr(fun.account, "DeleteAccountRequest") #safety is first in Jmthon 😎
